package com.example.homecommands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.literal;

public class SetHomeCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("sethome")
            .executes(context -> executeSetHome(context.getSource()))
        );
    }

    private static int executeSetHome(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.literal("This command can only be executed by a player"));
            return 0;
        }

        HomeCommandsMod.getInstance().getHomeManager().setHome(player);
        source.sendFeedback(() -> Text.literal("Home set to current location"), false);
        return 1;
    }
}