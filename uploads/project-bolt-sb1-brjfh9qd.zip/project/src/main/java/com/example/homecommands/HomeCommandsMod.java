package com.example.homecommands;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomeCommandsMod implements ModInitializer {
    private static HomeCommandsMod instance;
    private final Logger logger = LoggerFactory.getLogger("home-commands");
    private final HomeManager homeManager;

    public HomeCommandsMod() {
        instance = this;
        this.homeManager = new HomeManager();
    }

    @Override
    public void onInitialize() {
        this.logger.info("Initializing Home Commands Mod");
        this.registerCommands();
    }

    private void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            HomeCommand.register(dispatcher);
            SetHomeCommand.register(dispatcher);
            DelHomeCommand.register(dispatcher);
        });
    }

    public static HomeCommandsMod getInstance() {
        return instance;
    }

    public HomeManager getHomeManager() {
        return this.homeManager;
    }

    public Logger getLogger() {
        return this.logger;
    }
}