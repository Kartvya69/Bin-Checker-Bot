package com.example.homecommands;

import lombok.Data;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

@Data
public class Home {
    private final Vec3d position;
    private final float yaw;
    private final float pitch;
    private final String dimension;

    public static Home fromCurrentPosition(ServerWorld world, Vec3d pos, float yaw, float pitch) {
        String dimensionId = world.getRegistryKey().getValue().toString();
        return new Home(pos, yaw, pitch, dimensionId);
    }

    public RegistryKey<World> getDimensionKey() {
        return RegistryKey.of(RegistryKey.ofRegistry(new Identifier("dimension")), new Identifier(this.dimension));
    }
}