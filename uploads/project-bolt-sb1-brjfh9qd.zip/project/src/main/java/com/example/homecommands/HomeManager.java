package com.example.homecommands;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HomeManager {
    private final Map<UUID, Home> homes;
    private final Gson gson;
    private final Path saveFile;

    public HomeManager() {
        this.homes = new HashMap<>();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        this.saveFile = Path.of("config", "home-commands", "homes.json");
        this.loadHomes();
    }

    public void setHome(ServerPlayerEntity player) {
        Vec3d pos = player.getPos();
        Home home = Home.fromCurrentPosition(
            player.getServerWorld(),
            pos,
            player.getYaw(),
            player.getPitch()
        );
        this.homes.put(player.getUuid(), home);
        this.saveHomes();
    }

    public Home getHome(UUID playerId) {
        return this.homes.get(playerId);
    }

    public void deleteHome(UUID playerId) {
        this.homes.remove(playerId);
        this.saveHomes();
    }

    private void loadHomes() {
        try {
            if (!Files.exists(this.saveFile)) {
                Files.createDirectories(this.saveFile.getParent());
                return;
            }

            String json = Files.readString(this.saveFile);
            TypeToken<Map<UUID, Home>> typeToken = new TypeToken<>() {};
            Map<UUID, Home> loadedHomes = this.gson.fromJson(json, typeToken.getType());
            
            if (loadedHomes != null) {
                this.homes.putAll(loadedHomes);
            }
        } catch (IOException e) {
            HomeCommandsMod.getInstance().getLogger().error("Failed to load homes", e);
        }
    }

    private void saveHomes() {
        try {
            Files.createDirectories(this.saveFile.getParent());
            String json = this.gson.toJson(this.homes);
            Files.writeString(this.saveFile, json);
        } catch (IOException e) {
            HomeCommandsMod.getInstance().getLogger().error("Failed to save homes", e);
        }
    }
}