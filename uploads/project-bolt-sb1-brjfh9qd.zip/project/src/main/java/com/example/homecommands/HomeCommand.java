package com.example.homecommands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.server.world.ServerWorld;

import static net.minecraft.server.command.CommandManager.literal;

public class HomeCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(literal("home")
            .executes(context -> executeHome(context.getSource()))
        );
    }

    private static int executeHome(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.literal("This command can only be executed by a player"));
            return 0;
        }

        Home home = HomeCommandsMod.getInstance().getHomeManager().getHome(player.getUuid());
        if (home == null) {
            source.sendError(Text.literal("You haven't set a home yet. Use /sethome to set one"));
            return 0;
        }

        ServerWorld targetWorld = source.getServer().getWorld(home.getDimensionKey());
        if (targetWorld == null) {
            source.sendError(Text.literal("Target dimension not found"));
            return 0;
        }

        player.teleport(
            targetWorld,
            home.getPosition().x,
            home.getPosition().y,
            home.getPosition().z,
            home.getYaw(),
            home.getPitch()
        );

        source.sendFeedback(() -> Text.literal("Teleported to home"), false);
        return 1;
    }
}