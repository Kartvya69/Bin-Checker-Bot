package com.example.angeldevil.abilities;

import com.example.angeldevil.AngelDevilPlugin;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public class AngelAbilities {
    private final AngelDevilPlugin plugin;
    
    public AngelAbilities(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void dash(Player player) {
        if (plugin.getPowerManager().isOnCooldown(player.getUniqueId(), "dash")) {
            player.sendMessage("Dash is on cooldown!");
            return;
        }
        
        Vector direction = player.getLocation().getDirection();
        direction.multiply(2); // Dash strength
        player.setVelocity(direction);
        
        plugin.getPowerManager().setCooldown(player.getUniqueId(), "dash", 
            plugin.getConfig().getInt("powers.angel.dash.cooldown"));
    }
    
    public void createStickRing(Player player) {
        Location center = player.getLocation();
        World world = player.getWorld();
        
        for (int i = 0; i < 8; i++) {
            double angle = (2 * Math.PI * i) / 8;
            double x = center.getX() + 3 * Math.cos(angle);
            double z = center.getZ() + 3 * Math.sin(angle);
            Location stickLoc = new Location(world, x, center.getY(), z);
            
            world.dropItem(stickLoc, new ItemStack(Material.STICK));
        }
    }
    
    public void applyDimensionEffects(Player player) {
        World.Environment env = player.getWorld().getEnvironment();
        
        switch (env) {
            case NETHER:
                player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 
                    Integer.MAX_VALUE, 0, false, false));
                break;
            case NORMAL:
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST,
                    Integer.MAX_VALUE, 1, false, false));
                break;
        }
    }
}