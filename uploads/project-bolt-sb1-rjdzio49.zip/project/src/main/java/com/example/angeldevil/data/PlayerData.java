package com.example.angeldevil.data;

import com.example.angeldevil.enums.PlayerChoice;
import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private PlayerChoice choice;
    private int level;
    private int experience;
    
    public PlayerData(UUID uuid) {
        this.uuid = uuid;
        reset();
    }
    
    public UUID getUuid() {
        return uuid;
    }
    
    public PlayerChoice getChoice() {
        return choice;
    }
    
    public void setChoice(PlayerChoice choice) {
        this.choice = choice;
    }
    
    public int getLevel() {
        return level;
    }
    
    public int getExperience() {
        return experience;
    }
    
    public void addExperience(int amount) {
        this.experience += amount;
        calculateLevel();
    }
    
    private void calculateLevel() {
        // Simple level calculation: each level requires 1000 * level experience
        int newLevel = (int) Math.floor(Math.sqrt(experience / 1000.0));
        this.level = Math.min(newLevel, 3); // Max level is 3
    }
    
    public void reset() {
        this.choice = null;
        this.level = 0;
        this.experience = 0;
    }
}