package com.example.angeldevil.commands;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.enums.PlayerChoice;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ChooseCommand implements CommandExecutor {
    private final AngelDevilPlugin plugin;
    
    public ChooseCommand(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players!");
            return true;
        }
        
        if (args.length != 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /choose <angel/devil>");
            return true;
        }
        
        Player player = (Player) sender;
        String choice = args[0].toLowerCase();
        
        switch (choice) {
            case "angel":
                plugin.getPlayerManager().setChoice(player.getUniqueId(), PlayerChoice.ANGEL);
                player.sendMessage(ChatColor.GREEN + "You have chosen the path of the Angel!");
                break;
            case "devil":
                plugin.getPlayerManager().setChoice(player.getUniqueId(), PlayerChoice.DEVIL);
                player.sendMessage(ChatColor.RED + "You have chosen the path of the Devil!");
                break;
            default:
                player.sendMessage(ChatColor.RED + "Invalid choice! Use 'angel' or 'devil'");
                return true;
        }
        
        plugin.getPowerManager().applyPowers(player);
        return true;
    }
}