package com.example.angeldevil.commands;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.data.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PowersCommand implements CommandExecutor {
    private final AngelDevilPlugin plugin;
    
    public PowersCommand(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players!");
            return true;
        }
        
        Player player = (Player) sender;
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        
        if (data == null || data.getChoice() == null) {
            player.sendMessage(ChatColor.RED + "You haven't chosen a side yet! Use /choose <angel/devil>");
            return true;
        }
        
        player.sendMessage(ChatColor.GOLD + "=== Your Powers ===");
        player.sendMessage(ChatColor.YELLOW + "Side: " + data.getChoice());
        player.sendMessage(ChatColor.YELLOW + "Level: " + data.getLevel());
        player.sendMessage(ChatColor.YELLOW + "Experience: " + data.getExperience());
        
        // List available powers based on choice and level
        listPowers(player, data);
        
        return true;
    }
    
    private void listPowers(Player player, PlayerData data) {
        player.sendMessage(ChatColor.GOLD + "Available Powers:");
        
        switch (data.getChoice()) {
            case ANGEL:
                player.sendMessage(ChatColor.WHITE + "- No fall damage");
                if (data.getLevel() >= 1) {
                    player.sendMessage(ChatColor.WHITE + "- Dash ability");
                }
                if (data.getLevel() >= 2) {
                    player.sendMessage(ChatColor.WHITE + "- Speed effect");
                }
                if (data.getLevel() >= 3) {
                    player.sendMessage(ChatColor.WHITE + "- Stick Ring");
                }
                break;
            case DEVIL:
                player.sendMessage(ChatColor.WHITE + "- Fire resistance");
                if (data.getLevel() >= 1) {
                    player.sendMessage(ChatColor.WHITE + "- Fireball (Strength 1)");
                }
                if (data.getLevel() >= 2) {
                    player.sendMessage(ChatColor.WHITE + "- Fireball (Strength 2)");
                }
                if (data.getLevel() >= 3) {
                    player.sendMessage(ChatColor.WHITE + "- Tracking compass");
                }
                break;
        }
    }
}