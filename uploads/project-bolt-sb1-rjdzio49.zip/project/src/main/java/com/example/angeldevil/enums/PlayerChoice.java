package com.example.angeldevil.enums;

public enum PlayerChoice {
    ANGEL,
    DEVIL
}