package com.example.angeldevil.managers;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.abilities.AngelAbilities;
import com.example.angeldevil.abilities.DevilAbilities;
import com.example.angeldevil.data.PlayerData;
import com.example.angeldevil.enums.PlayerChoice;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PowerManager {
    private final AngelDevilPlugin plugin;
    private final Map<UUID, Long> cooldowns;
    private final AngelAbilities angelAbilities;
    private final DevilAbilities devilAbilities;
    
    public PowerManager(AngelDevilPlugin plugin) {
        this.plugin = plugin;
        this.cooldowns = new HashMap<>();
        this.angelAbilities = new AngelAbilities(plugin);
        this.devilAbilities = new DevilAbilities(plugin);
    }
    
    public void applyPowers(Player player) {
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null) return;
        
        // Remove all effects first
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        
        if (data.getChoice() == PlayerChoice.ANGEL) {
            applyAngelPowers(player, data.getLevel());
            angelAbilities.applyDimensionEffects(player);
        } else if (data.getChoice() == PlayerChoice.DEVIL) {
            applyDevilPowers(player, data.getLevel());
            devilAbilities.applyDimensionEffects(player);
        }
    }
    
    private void applyAngelPowers(Player player, int level) {
        // Level 0: No fall damage (handled in listener)
        
        // Level 1+: Speed effect
        if (level >= 1) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 
                plugin.getConfig().getInt("powers.angel.speed.duration") * 20,
                plugin.getConfig().getInt("powers.angel.speed.level") - 1));
        }
        
        // Level 3: Create stick ring
        if (level >= 3) {
            angelAbilities.createStickRing(player);
        }
    }
    
    private void applyDevilPowers(Player player, int level) {
        // Level 0: Fire resistance
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
            plugin.getConfig().getInt("powers.devil.fire_resistance.duration") * 20, 0));
            
        // Level 3: Give tracking compass
        if (level >= 3) {
            devilAbilities.giveTrackingCompass(player);
        }
    }
    
    public void activateAbility(Player player, String ability) {
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null) return;
        
        switch (data.getChoice()) {
            case ANGEL:
                if (ability.equals("dash") && data.getLevel() >= 1) {
                    angelAbilities.dash(player);
                }
                break;
            case DEVIL:
                if (ability.equals("fireball") && data.getLevel() >= 1) {
                    devilAbilities.shootFireball(player, data.getLevel());
                }
                break;
        }
    }
    
    public boolean isOnCooldown(UUID uuid, String ability) {
        String key = uuid.toString() + ":" + ability;
        if (!cooldowns.containsKey(UUID.fromString(key))) return false;
        
        long cooldownTime = cooldowns.get(UUID.fromString(key));
        if (System.currentTimeMillis() >= cooldownTime) {
            cooldowns.remove(UUID.fromString(key));
            return false;
        }
        return true;
    }
    
    public void setCooldown(UUID uuid, String ability, int seconds) {
        String key = uuid.toString() + ":" + ability;
        cooldowns.put(UUID.fromString(key), 
            System.currentTimeMillis() + (seconds * 1000L));
    }
    
    public AngelAbilities getAngelAbilities() {
        return angelAbilities;
    }
    
    public DevilAbilities getDevilAbilities() {
        return devilAbilities;
    }
}