package com.example.angeldevil.listeners;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.data.PlayerData;
import com.example.angeldevil.enums.PlayerChoice;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class PowerListener implements Listener {
    private final AngelDevilPlugin plugin;
    
    public PowerListener(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onFallDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        if (event.getCause() != EntityDamageEvent.DamageCause.FALL) return;
        
        Player player = (Player) event.getEntity();
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        
        if (data != null && data.getChoice() == PlayerChoice.ANGEL) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        plugin.getPowerManager().applyPowers(player);
    }
    
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && 
            event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
            
        Player player = event.getPlayer();
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        
        if (data == null || data.getChoice() == null) return;
        
        // Angel dash with feather
        if (data.getChoice() == PlayerChoice.ANGEL && 
            event.getMaterial() == Material.FEATHER) {
            plugin.getPowerManager().activateAbility(player, "dash");
        }
        
        // Devil fireball with blaze powder
        if (data.getChoice() == PlayerChoice.DEVIL && 
            event.getMaterial() == Material.BLAZE_POWDER) {
            plugin.getPowerManager().activateAbility(player, "fireball");
        }
    }
}