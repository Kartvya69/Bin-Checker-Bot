import { createOpenAI, openai } from "@ai-sdk/openai"
import { streamText } from "ai"

// Allow streaming responses up to 30 seconds
export const maxDuration = 30

export async function POST(req: Request) {
  const { messages, customBaseUrl } = await req.json()

  // Create a custom OpenAI provider if a custom base URL is provided
  const provider = customBaseUrl
    ? createOpenAI({
        baseURL: customBaseUrl,
        apiKey: process.env.OPENAI_API_KEY || "",
      })
    : openai

  const result = streamText({
    model: provider("gpt-4-turbo"),
    system: "You are a helpful assistant.",
    messages,
  })

  return result.toDataStreamResponse()
}

