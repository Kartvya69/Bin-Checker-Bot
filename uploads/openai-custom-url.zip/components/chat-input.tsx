"use client"

import { useEnterSubmit } from "@/lib/hooks/use-enter-submit"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"
import { useEffect, useRef, useState } from "react"
import TextareaAutosize from "react-textarea-autosize"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip"
import { IconArrowElbow } from "@/components/ui/icons"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Settings } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

export function ChatInput({ id, initialMessages, className, onSubmit, ...props }) {
  const router = useRouter()
  const { formRef, onKeyDown } = useEnterSubmit()
  const inputRef = useRef(null)
  const [customBaseUrl, setCustomBaseUrl] = useState("")
  const [useCustomUrl, setUseCustomUrl] = useState(false)

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  return (
    <TooltipProvider>
      <form
        ref={formRef}
        onSubmit={async (e) => {
          e.preventDefault()
          if (!inputRef.current?.value?.trim()) {
            return
          }

          const value = inputRef.current.value
          inputRef.current.value = ""

          // Pass the custom base URL if enabled
          const options = useCustomUrl && customBaseUrl ? { customBaseUrl } : {}

          onSubmit({
            content: value,
            role: "user",
            ...options,
          })
        }}
        className={cn("relative flex w-full grow flex-col", className)}
        {...props}
      >
        <div className="relative flex w-full grow items-center">
          <TextareaAutosize
            ref={inputRef}
            tabIndex={0}
            onKeyDown={onKeyDown}
            rows={1}
            placeholder="Send a message."
            spellCheck={false}
            className="min-h-[60px] w-full resize-none bg-transparent px-4 py-[1.3rem] focus-within:outline-none sm:text-sm"
          />
          <div className="absolute right-2 flex space-x-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="h-5 w-5" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                <div className="grid gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium leading-none">API Settings</h4>
                    <p className="text-sm text-muted-foreground">Configure custom API endpoints</p>
                  </div>
                  <div className="grid gap-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="use-custom-url">Use custom OpenAI URL</Label>
                      <Switch id="use-custom-url" checked={useCustomUrl} onCheckedChange={setUseCustomUrl} />
                    </div>
                    {useCustomUrl && (
                      <div className="grid gap-2">
                        <Label htmlFor="custom-base-url">Base URL</Label>
                        <Input
                          id="custom-base-url"
                          placeholder="https://your-proxy.com/v1"
                          value={customBaseUrl}
                          onChange={(e) => setCustomBaseUrl(e.target.value)}
                        />
                      </div>
                    )}
                  </div>
                </div>
              </PopoverContent>
            </Popover>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button type="submit" size="icon">
                  <IconArrowElbow />
                  <span className="sr-only">Send message</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>Send message</TooltipContent>
            </Tooltip>
          </div>
        </div>
      </form>
    </TooltipProvider>
  )
}

