import type React from "react"
import { cn } from "@/lib/utils"

export function FooterText({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p className={cn("px-2 text-center text-xs leading-normal text-muted-foreground", className)} {...props}>
      Open source AI chatbot built with{" "}
      <a
        href="https://nextjs.org"
        target="_blank"
        rel="noopener noreferrer"
        className="font-medium underline underline-offset-4"
      >
        Next.js
      </a>{" "}
      and{" "}
      <a
        href="https://sdk.vercel.ai/docs"
        target="_blank"
        rel="noopener noreferrer"
        className="font-medium underline underline-offset-4"
      >
        Vercel AI SDK
      </a>
      .
    </p>
  )
}

