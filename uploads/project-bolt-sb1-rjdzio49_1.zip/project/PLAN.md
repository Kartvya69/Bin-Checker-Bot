# Minecraft Angel vs Devil Plugin Development Plan

## 1. Project Setup
- Initialize Gradle project with Paper API 1.21.1
- Set up basic plugin structure
- Configure dependencies (Gson)

## 2. Core Systems

### 2.1 Player Choice System
- Implement Angel/Devil selection mechanism
- Store player choices persistently
- Create commands for selection

### 2.2 Level System
- Create level progression system
- Store player levels
- Implement experience/progression mechanics

### 2.3 Power Systems

#### Angel Powers
- Level 0: No fall damage
- Level 1: Dash ability
- Level 2: Dash + Speed effect
- Level 3: Dash + Speed 1 + Stick Ring
- Special: Glow in Nether, Heart boost in Overworld

#### Devil Powers
- Level 0: Fire resistance
- Level 1: Fireball strength 1
- Level 2: Fireball strength 2
- Level 3: Enhanced fireball + Tracking compass
- Special: Glow in Nether, Haste 2 in Overworld

### 2.4 Chat Moderation
- Implement HTTP client for API requests
- Create chat event listener
- Process and moderate messages
- Cache responses to avoid excessive API calls

## 3. Implementation Phases

### Phase 1: Foundation
1. Set up project structure
2. Implement basic plugin functionality
3. Create player data management system

### Phase 2: Choice System
1. Implement Angel/Devil selection
2. Create persistent storage
3. Add basic commands

### Phase 3: Powers
1. Implement level system
2. Add Angel powers
3. Add Devil powers
4. Add dimension-specific effects

### Phase 4: Chat Moderation
1. Create HTTP client
2. Implement chat listener
3. Add moderation logic
4. Implement caching system

### Phase 5: Polish
1. Add configuration options
2. Implement permissions
3. Add messages and localization
4. Performance optimization

## 4. Technical Details

### Data Storage
- Use YAML/JSON for player data
- Store choices, levels, and progression

### Commands
- /choose <angel/devil>
- /powers
- /level
- /reset

### Events to Handle
- PlayerJoinEvent
- PlayerQuitEvent
- EntityDamageEvent
- PlayerMoveEvent
- AsyncPlayerChatEvent
- PlayerChangedWorldEvent

### Configuration
- Power settings
- Level requirements
- Chat moderation settings
- Messages and localization