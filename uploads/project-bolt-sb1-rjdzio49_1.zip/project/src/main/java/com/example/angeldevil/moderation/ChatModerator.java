package com.example.angeldevil.moderation;

import com.example.angeldevil.AngelDevilPlugin;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public class ChatModerator {
    private final AngelDevilPlugin plugin;
    private final HttpClient client;
    private final Gson gson;
    private final Map<String, ModerationResult> cache;
    
    public ChatModerator(AngelDevilPlugin plugin) {
        this.plugin = plugin;
        this.client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofMillis(plugin.getConfig().getLong("chat.moderation.timeout")))
            .build();
        this.gson = new Gson();
        this.cache = new HashMap<>();
    }
    
    public CompletableFuture<Boolean> isMessageAppropriate(String message) {
        // Check cache first
        ModerationResult cached = cache.get(message);
        if (cached != null && !cached.isExpired()) {
            return CompletableFuture.completedFuture(cached.isAppropriate());
        }
        
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("input", message);
        
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(plugin.getConfig().getString("chat.moderation.api_url")))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(requestBody.toString()))
            .build();
            
        return client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .thenApply(HttpResponse::body)
            .thenApply(this::parseResponse)
            .thenApply(result -> {
                cache.put(message, new ModerationResult(result, 
                    System.currentTimeMillis() + plugin.getConfig().getLong("chat.moderation.cache_duration") * 1000));
                return result;
            });
    }
    
    private boolean parseResponse(String response) {
        try {
            JsonObject json = gson.fromJson(response, JsonObject.class);
            return !json.getAsJsonObject("results")
                .getAsJsonArray("categories")
                .get(0)
                .getAsJsonObject()
                .get("flagged")
                .getAsBoolean();
        } catch (Exception e) {
            plugin.getLogger().warning("Error parsing moderation response: " + e.getMessage());
            return true; // Allow message if parsing fails
        }
    }
    
    private static class ModerationResult {
        private final boolean appropriate;
        private final long expiryTime;
        
        public ModerationResult(boolean appropriate, long expiryTime) {
            this.appropriate = appropriate;
            this.expiryTime = expiryTime;
        }
        
        public boolean isAppropriate() {
            return appropriate;
        }
        
        public boolean isExpired() {
            return System.currentTimeMillis() > expiryTime;
        }
    }
}