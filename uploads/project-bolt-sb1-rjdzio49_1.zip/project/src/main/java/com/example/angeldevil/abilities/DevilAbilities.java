package com.example.angeldevil.abilities;

import com.example.angeldevil.AngelDevilPlugin;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.CompassMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class DevilAbilities {
    private final AngelDevilPlugin plugin;
    
    public DevilAbilities(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void shootFireball(Player player, int level) {
        if (plugin.getPowerManager().isOnCooldown(player.getUniqueId(), "fireball")) {
            player.sendMessage(plugin.getMessageConfig().getString("powers.cooldown"));
            return;
        }
        
        Fireball fireball = player.launchProjectile(Fireball.class);
        float strength = (float) (plugin.getConfig().getDouble("powers.devil.fireball.strength_multiplier") * level);
        fireball.setYield(strength);
        
        player.sendMessage(plugin.getMessageConfig().getString("powers.fireball.activated"));
        
        plugin.getPowerManager().setCooldown(player.getUniqueId(), "fireball",
            plugin.getConfig().getInt("powers.devil.fireball.cooldown"));
    }
    
    public void giveTrackingCompass(Player player) {
        ItemStack compass = new ItemStack(Material.COMPASS);
        CompassMeta meta = (CompassMeta) compass.getItemMeta();
        meta.setLodestone(player.getWorld().getSpawnLocation());
        meta.setLodestoneTracked(true);
        compass.setItemMeta(meta);
        
        player.getInventory().addItem(compass);
    }
    
    public void applyDimensionEffects(Player player) {
        World.Environment env = player.getWorld().getEnvironment();
        
        switch (env) {
            case NETHER:
                player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING,
                    Integer.MAX_VALUE, 0, false, false));
                break;
            case NORMAL:
                player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING,
                    Integer.MAX_VALUE, 1, false, false));
                break;
        }
    }
}