package com.example.angeldevil;

import com.example.angeldevil.commands.*;
import com.example.angeldevil.listeners.*;
import com.example.angeldevil.managers.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class AngelDevilPlugin extends JavaPlugin {
    private static AngelDevilPlugin instance;
    private PlayerManager playerManager;
    private PowerManager powerManager;
    private FileConfiguration messageConfig;
    private File messageFile;

    @Override
    public void onEnable() {
        instance = this;
        
        // Save default configs
        saveDefaultConfig();
        saveResource("messages.yml", false);
        
        // Load messages
        messageFile = new File(getDataFolder(), "messages.yml");
        messageConfig = YamlConfiguration.loadConfiguration(messageFile);
        
        // Initialize managers
        this.playerManager = new PlayerManager(this);
        this.powerManager = new PowerManager(this);
        
        // Register commands
        registerCommands();
        
        // Register listeners
        registerListeners();
        
        getLogger().info("AngelDevil plugin has been enabled!");
    }

    @Override
    public void onDisable() {
        // Save all player data
        if (playerManager != null) {
            playerManager.saveAllPlayers();
        }
        
        getLogger().info("AngelDevil plugin has been disabled!");
    }
    
    private void registerCommands() {
        getCommand("choose").setExecutor(new ChooseCommand(this));
        getCommand("powers").setExecutor(new PowersCommand(this));
        getCommand("level").setExecutor(new LevelCommand(this));
        getCommand("reset").setExecutor(new ResetCommand(this));
    }
    
    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new PowerListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
    }
    
    public static AngelDevilPlugin getInstance() {
        return instance;
    }
    
    public PlayerManager getPlayerManager() {
        return playerManager;
    }
    
    public PowerManager getPowerManager() {
        return powerManager;
    }
    
    public FileConfiguration getMessageConfig() {
        return messageConfig;
    }
}