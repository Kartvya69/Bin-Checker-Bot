package com.example.angeldevil.commands;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.data.PlayerData;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LevelCommand implements CommandExecutor {
    private final AngelDevilPlugin plugin;
    
    public LevelCommand(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players!");
            return true;
        }
        
        Player player = (Player) sender;
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        
        if (data == null || data.getChoice() == null) {
            player.sendMessage(ChatColor.RED + "You haven't chosen a side yet! Use /choose <angel/devil>");
            return true;
        }
        
        int expToNext = ((data.getLevel() + 1) * 1000) - data.getExperience();
        
        player.sendMessage(ChatColor.GOLD + "=== Level Information ===");
        player.sendMessage(ChatColor.YELLOW + "Current Level: " + data.getLevel());
        player.sendMessage(ChatColor.YELLOW + "Experience: " + data.getExperience());
        if (data.getLevel() < 3) {
            player.sendMessage(ChatColor.YELLOW + "Experience needed for next level: " + expToNext);
        } else {
            player.sendMessage(ChatColor.GREEN + "Maximum level reached!");
        }
        
        return true;
    }
}