package com.example.angeldevil.listeners;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.enums.PlayerChoice;
import com.example.angeldevil.utils.MessageUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIListener implements Listener {
    private final AngelDevilPlugin plugin;
    
    public GUIListener(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals(
            MessageUtils.color(plugin.getMessageConfig().getString("choice.gui.title")))) {
            return;
        }
        
        event.setCancelled(true);
        
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        
        Player player = (Player) event.getWhoClicked();
        
        if (plugin.getPlayerManager().getPlayerData(player.getUniqueId()).getChoice() != null) {
            player.sendMessage(MessageUtils.color(plugin.getMessageConfig().getString("choice.already_chosen")));
            player.closeInventory();
            return;
        }
        
        if (event.getCurrentItem() == null) {
            return;
        }
        
        switch (event.getCurrentItem().getType()) {
            case FEATHER:
                plugin.getPlayerManager().setChoice(player.getUniqueId(), PlayerChoice.ANGEL);
                player.sendMessage(MessageUtils.color(plugin.getMessageConfig().getString("choice.selected.angel")));
                break;
            case BLAZE_POWDER:
                plugin.getPlayerManager().setChoice(player.getUniqueId(), PlayerChoice.DEVIL);
                player.sendMessage(MessageUtils.color(plugin.getMessageConfig().getString("choice.selected.devil")));
                break;
            default:
                return;
        }
        
        player.closeInventory();
        plugin.getPowerManager().applyPowers(player);
    }
}