package com.example.angeldevil.gui;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.enums.PlayerChoice;
import com.example.angeldevil.utils.MessageUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ChoiceGUI {
    private final AngelDevilPlugin plugin;
    
    public ChoiceGUI(AngelDevilPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void openGUI(Player player) {
        Inventory gui = Bukkit.createInventory(null, 27, 
            MessageUtils.color(plugin.getMessageConfig().getString("choice.gui.title")));
        
        // Angel Choice (Feather)
        ItemStack angelItem = new ItemStack(Material.FEATHER);
        ItemMeta angelMeta = angelItem.getItemMeta();
        angelMeta.setDisplayName(MessageUtils.color(plugin.getMessageConfig().getString("choice.gui.angel.name")));
        List<String> angelLore = new ArrayList<>();
        for (String line : plugin.getMessageConfig().getStringList("choice.gui.angel.lore")) {
            angelLore.add(MessageUtils.color(line));
        }
        angelMeta.setLore(angelLore);
        angelItem.setItemMeta(angelMeta);
        
        // Devil Choice (Blaze Powder)
        ItemStack devilItem = new ItemStack(Material.BLAZE_POWDER);
        ItemMeta devilMeta = devilItem.getItemMeta();
        devilMeta.setDisplayName(MessageUtils.color(plugin.getMessageConfig().getString("choice.gui.devil.name")));
        List<String> devilLore = new ArrayList<>();
        for (String line : plugin.getMessageConfig().getStringList("choice.gui.devil.lore")) {
            devilLore.add(MessageUtils.color(line));
        }
        devilMeta.setLore(devilLore);
        devilItem.setItemMeta(devilMeta);
        
        // Fill with glass panes
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName(" ");
        filler.setItemMeta(fillerMeta);
        
        for (int i = 0; i < gui.getSize(); i++) {
            gui.setItem(i, filler);
        }
        
        // Set choice items
        gui.setItem(11, angelItem);
        gui.setItem(15, devilItem);
        
        player.openInventory(gui);
    }
}