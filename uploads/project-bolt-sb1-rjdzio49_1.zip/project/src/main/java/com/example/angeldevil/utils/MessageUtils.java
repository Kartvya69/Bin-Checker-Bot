package com.example.angeldevil.utils;

import org.bukkit.ChatColor;

public class MessageUtils {
    public static String color(String message) {
        if (message == null) return "";
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    public static String replacePlaceholders(String message, String... replacements) {
        if (message == null) return "";
        if (replacements.length % 2 != 0) {
            throw new IllegalArgumentException("Replacements must be in pairs!");
        }
        
        String result = message;
        for (int i = 0; i < replacements.length; i += 2) {
            result = result.replace(replacements[i], replacements[i + 1]);
        }
        
        return color(result);
    }
}