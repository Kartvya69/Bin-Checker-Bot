package com.example.angeldevil.listeners;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.moderation.ChatModerator;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {
    private final AngelDevilPlugin plugin;
    private final ChatModerator moderator;
    
    public ChatListener(AngelDevilPlugin plugin) {
        this.plugin = plugin;
        this.moderator = new ChatModerator(plugin);
    }
    
    @EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (!plugin.getConfig().getBoolean("chat.moderation.enabled")) return;
        
        moderator.isMessageAppropriate(event.getMessage())
            .thenAccept(appropriate -> {
                if (!appropriate) {
                    event.setCancelled(true);
                    event.getPlayer().sendMessage(ChatColor.RED + "Your message was flagged as inappropriate.");
                }
            });
    }
}