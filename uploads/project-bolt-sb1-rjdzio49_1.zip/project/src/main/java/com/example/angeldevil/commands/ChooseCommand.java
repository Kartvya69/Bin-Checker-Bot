package com.example.angeldevil.commands;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.gui.ChoiceGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ChooseCommand implements CommandExecutor {
    private final AngelDevilPlugin plugin;
    private final ChoiceGUI gui;
    
    public ChooseCommand(AngelDevilPlugin plugin) {
        this.plugin = plugin;
        this.gui = new ChoiceGUI(plugin);
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be used by players!");
            return true;
        }
        
        Player player = (Player) sender;
        gui.openGUI(player);
        return true;
    }
}