package com.example.angeldevil.managers;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.abilities.AngelAbilities;
import com.example.angeldevil.abilities.DevilAbilities;
import com.example.angeldevil.data.PlayerData;
import com.example.angeldevil.enums.PlayerChoice;
import com.example.angeldevil.utils.MessageUtils;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PowerManager {
    private final AngelDevilPlugin plugin;
    private final Map<UUID, Long> cooldowns;
    private final AngelAbilities angelAbilities;
    private final DevilAbilities devilAbilities;
    
    public PowerManager(AngelDevilPlugin plugin) {
        this.plugin = plugin;
        this.cooldowns = new HashMap<>();
        this.angelAbilities = new AngelAbilities(plugin);
        this.devilAbilities = new DevilAbilities(plugin);
        startParticleEffects();
    }
    
    private void startParticleEffects() {
        if (!plugin.getConfig().getBoolean("gui.particles.enabled")) return;
        
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : plugin.getServer().getOnlinePlayers()) {
                    PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
                    if (data == null || data.getChoice() == null) continue;
                    
                    Particle particle = data.getChoice() == PlayerChoice.ANGEL ? 
                        Particle.END_ROD : Particle.FLAME;
                    
                    player.getWorld().spawnParticle(particle, 
                        player.getLocation().add(0, 1, 0),
                        plugin.getConfig().getInt("gui.particles.amount"),
                        0.5, 0.5, 0.5, 0.02);
                }
            }
        }.runTaskTimer(plugin, 0L, plugin.getConfig().getLong("gui.update_interval"));
    }
    
    public void applyPowers(Player player) {
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null) return;
        
        // Remove all effects first
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        
        if (data.getChoice() == PlayerChoice.ANGEL) {
            applyAngelPowers(player, data.getLevel());
            applyDimensionEffects(player, "angel");
        } else if (data.getChoice() == PlayerChoice.DEVIL) {
            applyDevilPowers(player, data.getLevel());
            applyDimensionEffects(player, "devil");
        }
    }
    
    private void applyDimensionEffects(Player player, String side) {
        World.Environment env = player.getWorld().getEnvironment();
        String dimension = env == World.Environment.NETHER ? "nether" : "overworld";
        
        String path = "dimension_effects." + side + "." + dimension + ".";
        
        if (plugin.getConfig().getBoolean(path + "glowing")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 
                Integer.MAX_VALUE, 0, false, false));
        }
        
        if (plugin.getConfig().contains(path + "health_boost")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST,
                Integer.MAX_VALUE, plugin.getConfig().getInt(path + "health_boost") - 1,
                false, false));
        }
        
        if (plugin.getConfig().contains(path + "haste")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING,
                Integer.MAX_VALUE, plugin.getConfig().getInt(path + "haste") - 1,
                false, false));
        }
        
        if (plugin.getConfig().contains(path + "strength")) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE,
                Integer.MAX_VALUE, plugin.getConfig().getInt(path + "strength") - 1,
                false, false));
        }
    }
    
    private void applyAngelPowers(Player player, int level) {
        // Level 0: No fall damage (handled in listener)
        
        // Level 1+: Speed effect
        if (level >= 1) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 
                plugin.getConfig().getInt("powers.angel.speed.duration") * 20,
                plugin.getConfig().getInt("powers.angel.speed.level") - 1));
        }
        
        // Level 3: Create stick ring
        if (level >= 3) {
            angelAbilities.createStickRing(player);
        }
        
        // Apply heart boost
        player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST,
            plugin.getConfig().getInt("powers.angel.heart_boost.duration") * 20,
            plugin.getConfig().getInt("powers.angel.heart_boost.amount") - 1));
    }
    
    private void applyDevilPowers(Player player, int level) {
        // Level 0: Fire resistance
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE,
            plugin.getConfig().getInt("powers.devil.fire_resistance.duration") * 20, 0));
            
        // Level 3: Give tracking compass
        if (level >= 3) {
            devilAbilities.giveTrackingCompass(player);
        }
        
        // Apply haste
        player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING,
            plugin.getConfig().getInt("powers.devil.haste.duration") * 20,
            plugin.getConfig().getInt("powers.devil.haste.level") - 1));
    }
    
    public void activateAbility(Player player, String ability) {
        PlayerData data = plugin.getPlayerManager().getPlayerData(player.getUniqueId());
        if (data == null) return;
        
        switch (data.getChoice()) {
            case ANGEL:
                if (ability.equals("dash") && data.getLevel() >= 1) {
                    angelAbilities.dash(player);
                }
                break;
            case DEVIL:
                if (ability.equals("fireball") && data.getLevel() >= 1) {
                    devilAbilities.shootFireball(player, data.getLevel());
                }
                break;
        }
    }
    
    public boolean isOnCooldown(UUID uuid, String ability) {
        String key = uuid.toString() + ":" + ability;
        if (!cooldowns.containsKey(UUID.fromString(key))) return false;
        
        long cooldownTime = cooldowns.get(UUID.fromString(key));
        if (System.currentTimeMillis() >= cooldownTime) {
            cooldowns.remove(UUID.fromString(key));
            return false;
        }
        return true;
    }
    
    public void setCooldown(UUID uuid, String ability, int seconds) {
        String key = uuid.toString() + ":" + ability;
        cooldowns.put(UUID.fromString(key), 
            System.currentTimeMillis() + (seconds * 1000L));
    }
    
    public AngelAbilities getAngelAbilities() {
        return angelAbilities;
    }
    
    public DevilAbilities getDevilAbilities() {
        return devilAbilities;
    }
}