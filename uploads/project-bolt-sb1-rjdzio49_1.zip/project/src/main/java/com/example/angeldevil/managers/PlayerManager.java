package com.example.angeldevil.managers;

import com.example.angeldevil.AngelDevilPlugin;
import com.example.angeldevil.data.PlayerData;
import com.example.angeldevil.enums.PlayerChoice;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerManager {
    private final AngelDevilPlugin plugin;
    private final Map<UUID, PlayerData> playerData;
    
    public PlayerManager(AngelDevilPlugin plugin) {
        this.plugin = plugin;
        this.playerData = new HashMap<>();
    }
    
    public void loadPlayer(Player player) {
        // TODO: Load from storage
        PlayerData data = new PlayerData(player.getUniqueId());
        playerData.put(player.getUniqueId(), data);
    }
    
    public void savePlayer(UUID uuid) {
        PlayerData data = playerData.get(uuid);
        if (data != null) {
            // TODO: Save to storage
        }
    }
    
    public void saveAllPlayers() {
        for (UUID uuid : playerData.keySet()) {
            savePlayer(uuid);
        }
    }
    
    public PlayerData getPlayerData(UUID uuid) {
        return playerData.getOrDefault(uuid, null);
    }
    
    public void setChoice(UUID uuid, PlayerChoice choice) {
        PlayerData data = playerData.get(uuid);
        if (data != null) {
            data.setChoice(choice);
            savePlayer(uuid);
        }
    }
    
    public void addExperience(UUID uuid, int amount) {
        PlayerData data = playerData.get(uuid);
        if (data != null) {
            data.addExperience(amount);
            savePlayer(uuid);
        }
    }
    
    public void resetPlayer(UUID uuid) {
        PlayerData data = playerData.get(uuid);
        if (data != null) {
            data.reset();
            savePlayer(uuid);
        }
    }
}